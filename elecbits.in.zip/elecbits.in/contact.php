<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- 1.0 meta -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="Elecbits" content=" We make Electronics Easy.">
        <meta name="author" content="Elecbits">
        <meta name="keywords" content="responsive, elito, countdown, mailchimp, clean, simple">
        
        <!-- 2.0 title -->
        <title>Elecbits | We make Electronics Easy.</title>
        
        <!-- 3.0 CSS IMPORT -->
        <!-- CSS IMPORT FOR PLUGIN -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/animate.min.css" type="text/css">
        <link rel="stylesheet" href="css/Pe-icon-7-stroke.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery.wordrotator.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
        <link rel="stylesheet" href="css/owl.theme.css" type="text/css">
        <link rel="stylesheet" href="css/loader.min.css" type="text/css">
        <link rel="stylesheet" href="css/perfect-scrollbar.css" type="text/css">
        <link rel="stylesheet" href="css/jquery.kenburnsy.css" type="text/css">
        

        <!-- CSS IMPORT FOR FONT -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" type="text/css">
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster" type="text/css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu" type="text/css">
        
        <!-- CSS IMPORT FOR MAIN STYLE AND COLOR SCHEME -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="css/color-scheme.css" type="text/css">
                        
        <!-- support HTML5 elements and media queries for IE9 -->
        <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
        <![endif]-->        
    </head>
    <body>
        <!-- 4.0 preloader -->
        <div class="preloader">
            <!-- content container -->
            <div class="content-container centering-y">
                <!-- logo -->
                <img src="img/logoeb.png" alt="logo" class="logo" />
                <!-- end logo -->
                
                <div class="line-scale-pulse-out-rapid">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
            <!-- end content container -->
        </div>
        <!-- end preloader -->
        
        <!-- 5.0 panel menu small -->
        <div class="panel-menu-small">
            <!-- menu icon container -->
            <div class="icon-container">
                <a href="#" class="link-menu-open"><i class="pe-7s-menu"></i></a>
            </div>
            <!-- end menu icon container -->
            
            <!-- menu text container -->
            <div class="text-container">
                menu
            </div>
            <!-- end menu text container -->
        </div>
        <!-- end panel menu small -->
        
        <!-- 6.0 panel menu big -->
        <div class="panel-menu-big" st>
            <!-- close panel -->
            <div class="close-menu-container centering-y">
                <a href="#" class="close-menu button-circle button-dark">x</a>
            </div>
            <!-- end close panel -->
                
            <!-- left side -->
            <div class="left-side col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <!-- content container -->
                <div class="content-container centering-y">
                    <img class="logo" src="img/logoeb.png" alt="logo" />
                    
                    <!-- 6.1 menu list -->
                    <nav class="menu-list">
                        <ul>
                            <li><a href="index.html" class="menu" >home</a></li>
                            <li><a href="about.html" class="menu" >about</a></li>
                            
                            <li><a  class="menu active " >contact</a></li>
                            
                        </ul>
                    </nav>
                    <!-- end menu list -->
                    
                    <!-- 6.2 social media container -->
                    <div class="social-media-container">
                       <a href="http://fb.com/elecbits7" class="social-link"><i class="fa fa-facebook"></i></a>
                        <a href="http://twitter.com/elecbits16" class="social-link"><i class="fa fa-twitter"></i></a>
                    </div>
                    <!-- end social media container -->
                </div>
                <!-- end content container -->
                
                <!-- 6.3 copyright -->
                <div class="copyright">
                    &copy; 2016 by Elecbits.
                </div>
                <!-- end copyright -->
            </div>
            <!-- end left side -->
            
            <!-- right side -->

            <div class="right-side col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <!-- content container -->
                <div class="content-container centering-y" >
                    <!-- 6.4 quote container -->
                    <div class="quote-container" >
                        <!-- quote 1 -->
                        <div class="quote menu-quote">
                            <p class="quote-2">Sometimes when you <br>innovate, you make <br>mnistakes. It is best to admit them quickly, and get on with improving your other innovations.</p>
                            <p class="quote-2-name">Steve Jobs</p>
                        </div>
                        <!-- end quote 1 -->
                        
                        <!-- quote 2 -->
                        <div class="quote menu-quote">
                            <p class="quote-2">You will never <br>win<br> if you never begin</p>
                            <p class="quote-2-name">Helen Rowland</p>
                        </div>
                        <!-- end quote 2 -->
                        
                        <!-- quote 3 -->
                        <div class="quote menu-quote">
                            <p class="quote-2">I won't quit<br> until <br> I know that I truly tried.</p>
                            <p class="quote-2-name">Elecbits</p>
                        </div>
                        <!-- end quote 3 -->
                    </div>
                    <!-- end quote container -->
                </div>
                <!-- end content container -->
            </div>
            <!-- end right side -->
        </div>
        <!-- end panel menu big --> 
        
        <!-- 7.0 page container -->
        <div class="page-container" >
            <!-- 7.1 background container -->
            <div class="bg-container" >
            </div>
            <!-- end background container -->
            
            <!-- 7.2 home section -->
            <section class="home-section"  >
                <!-- content container -->
               <div class="content-container col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
                    <!-- section title -->
                    <div class="section-title" style="padding: 30px; ">
                        <h2 style="color:white;">Get in Touch<br>&nbsp</h2>
                        
                    </div>
                    <!-- end section title -->
                    
                    <!-- 7.7.1 contact details -->
                    <div class="contact-details col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- location -->
                        <div class="location col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <p class="title">location</p>
                            <p class="detail"  style="color:black; font-weight: 20px; ">
                              <b> New Delhi <b>
                            </p>
                        </div>
                         
                        
                        <!-- email -->
                        <div class="email col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <p class="title">email</p>
                            <p class="detail" style="color:black; font-weight: 20px; ">
                               <b> elecbits16@gmail.com<b><br>
                                
                            </p>
                        </div>
                        <!-- end email -->
                        
                        <!-- phone -->
                        <div class="phone col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            <p class="title">phone</p>
                            <p class="detail"  style="color:black; font-weight: 20px; ">
                               <b>+91-9911806843<b>
                            </p>
                        </div>
                       
                    </div>
                    <!-- end contact details -->
                    
                    <!-- contact us description-->
                    <p class="contact-desc col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
                        
                    </p>
                  <!-- end contact us description -->
                    
                    <!-- 7.7.2 contact form container -->
                    <div class="contact-form-container col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-12 col-xs-12" style="background-color: white; ">
                        <form class="contact-form" action="php1/contactme.php" method="post" enctype="multipart/form-data">
                            <!-- left side -->
                            <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 col-xs-12 left-side">
                                <div class="form-row">
                                    <input type="text" class="contact-name" id="name" name="name" placeholder="Full Name" style="color:balck; font-weight: 40px; "/>
                                    <span class="user-icon"></span>
                                        
                                    <!-- this div is for form focus effect -->
                                    <div class="thin-line"></div>
                                    <!-- this div is for form focus effect -->
                                </div>
                            </div>
                            <!-- end left side -->
                                
                            <!-- right side -->
                            <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 col-xs-12 right-side">
                                <div class="form-row">
                                    <input type="email" class="contact-email" id="email" name="email1" autocomplete="off" placeholder="Enter your email address" style="color:black;"/>
                                    <span class="email-icon"></span>
                                        
                                    <!-- this div is for form focus effect -->
                                    <div class="thin-line"></div>
                                    <!-- this div is for form focus effect -->
                                </div>
                            </div>
                            <!-- end right side -->
                            
                            <!-- textarea -->
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-row">
                                    <textarea class="contact-message" id="message" name="message" placeholder="What are the difficulties you are facing while making your Electronics project ?" style="color:black;"></textarea>
                                    <span class="note-icon" ></span>
                                    
                                    <!-- this div is for form focus effect -->
                                    <div class="thin-line"></div>
                                    <!-- this div is for form focus effect -->
                                </div>
                            </div>
                            <!-- end textarea -->
                                    
                            <!-- notif container (to show success or error notif) -->
                            <div class="contact-notif col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            </div>
                            <!-- end notif container -->
                        
                            <!-- submit button -->
                            <div class="form-row submit-button">
                            <span class="icon"><i class="icon pe-7s-angle-right-circle"></i>
                                <input type="submit" class="button-round" name="update"  value="submit">
                                                                        
                                </input>
                                </span>
                            </div>
                            <!-- submit button -->
                        </form>
                    </div>
                    <!-- end contact form container -->
                </div>
                <!-- end content container -->
            </section>
            <!-- end home section -->
            
            <!-- 7.3 countdown section -->
            <section class="countdown-section">
                <!-- close button -->
                <div class="close-button-container">
                    <a href="#" class="close-countdown button-circle button-light">x</a>
                </div>
                <!-- end close button -->
                
                <!-- content container -->
                <div class="content-container col-lg-12 col-md-12 col-sm-12 col-xs-12 centering-y">
                    <!-- 7.3.1 countdown container -->
                    <div class="countdown-container" id="lwt-countdown">
                        <!-- days -->
                        <div class="dash days_dash">
                            <div class="digit">0</div><div class="digit">2</div><div class="digit">0</div>
                            <span class="dash_title">days</span>
                        </div>
                        <!-- end days -->
                    </div>
                    <!-- end countdown container -->
                    
                    <!-- text left -->
                    <div class="text-left centering-xy">
                        <h4>be patience<br>we are</h4>
                    </div>
                    <!-- end text left -->
                    
                    <!-- text right -->
                    <div class="text-right centering-xy">
                        <h4>left before<br>launch</h4>
                    </div>
                    <!-- end text right -->
                </div>
                <!-- end content container -->
            </section>
            <!-- end countdown section -->
            
            <!-- 7.4 subscribe section -->
            <section class="subscribe-section">
                <!-- close button -->
         
            </section>
            <!-- end subscribe section -->
            
            <!-- 7.5 about section -->
            <section id="#section-1" class="about-section">
                <!-- content container -->
         
                <!-- end content container -->
            </section>
            <!-- end about section -->
            
            <!-- 7.6 portfolio section -->
            <section class="portfolio-section">
                <!-- content container -->
       
                <!-- end content container -->
            </section>
            <!-- end portfolio section -->
            
            <!-- 7.7 contact section -->

            <!-- end contact section -->
        </div>
        <!-- end page container -->
                
        <!-- 8.0 javascript import --> 
        <!-- jquery -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <!-- bootstrap -->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <!-- countdown -->
        <script type="text/javascript" src="js/jquery.lwtCountdown-1.0.js"></script>
        <!-- backstretch -->
        <script type="text/javascript" src="js/jquery.backstretch.min.js"></script>
        <!-- jquery validate -->
        <script type="text/javascript" src="js/jquery.validate.min.js"></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <!-- wordsrotator -->
        <script type="text/javascript" src="js/jquery.wordrotator.min.js"></script>
        <!-- owl carousel -->
        <script type="text/javascript" src="js/owl.carousel.js"></script>
        <!-- perfect scrollbar -->
        <script type="text/javascript" src="js/perfect-scrollbar.min.js"></script>
        <!-- constellation (star-effect) -->
        <script type="text/javascript" src="js/constellation.js"></script>
        <!-- main js -->
        <script type="text/javascript" src="js/main_4.js"></script>
    </body>
</html>


