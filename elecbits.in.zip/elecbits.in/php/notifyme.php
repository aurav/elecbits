
<?php

if (isset($_POST['notify'])) {
	

	if(isset($_POST['email'])) {
		
		
		  $email =  $_POST["email"];
     
     
    
      
     $check =" $email ";
     
     
    $from= "from: Subscribe@elecbits.in";

if(filter_var($email, FILTER_VALIDATE_EMAIL)){


      if( mail("saurav.rav67@gmail.com", "Email Subscription", $check, $from) && mail($email, "Welcome to Elecbits", "Thanks for subscription to Elecbits, we will respond to you soon.  Meanwhile visit us at http://elecbits.in " , $from) ) 
      {  
           echo "Message Saved, please check your email confirmation. Meanwhile, <a href='http://elecbits.in'>Visit Us</a>";  
      }  
 }  
 
 else
 {
 echo "Wrong Email, please enter again";
 }
 
 }
 }


?>