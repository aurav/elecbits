<!--
	Write your contact script in this file. You can save the message in database, 
    but I give you a simple example to save the message in txt file.
    First, create an empty txt file. Name it customer_message.txt
-->
<?php
if (isset($_POST['update2'])) {
	
if(isset($_POST['email1']) && isset($_POST['name']) && isset($_POST['message'])){
		
      $email =  $_POST["email1"];
      $name =  $_POST["name"];
      $message =  $_POST["message"];
     
    
      
     $check =" $email , $name, $message ";
     
     
    $from= "from: JoinUs@elecbits.in";

if(filter_var($email, FILTER_VALIDATE_EMAIL)){


      if( mail("saurav.rav67@gmail.com", "Join Us", $check, $from) && mail($email, "Welcome to Elecbits", "Thanks for subscription to Elecbits, we will respond to you soon.  Meanwhile visit us at http://elecbits.in " , $from) ) 
      {  
           echo "Message Saved, please check your email confirmation. Meanwhile, <a href='http://elecbits.in'>Visit Us</a>";  
      }  
 }  
 
 else
 {
 echo "Wrong Email, please enter again";
 }
 
 }
 }
 ?>  