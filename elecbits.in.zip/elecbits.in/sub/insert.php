<?php  
 //insert.php  

 if(isset($_POST["name"]))  
 {  
      $name =  $_POST["name"];  
    
     $message =" $name";
     
     

    $from= "from: Elecbits@elecbits.in";

if(filter_var($name, FILTER_VALIDATE_EMAIL)){


      if( mail("saurav.rav67@gmail.com", "New Mail", $message, $from) && mail($name, "Welcome", "Thanks for subscription to Elecbits", $from) ) 
      {  
           echo "Message Saved";  
      }  
 }  
 
 else
 {
 echo "Wrong Email, please enter again";
 }
 
 }
 ?>  